# QuickDark
A really simple Chrome extension that changes Facebook, Facebook Messenger and Google to darker color.

This is still super work in progress. 

![Firefox Add-on](https://addons.mozilla.org/en-US/firefox/addon/quickdark/)

##Screenshots 
![Facebook](https://i.imgur.com/XU14XD7.png)
![Messenger](https://i.imgur.com/wefAJUT.jpg)
![Google](https://i.imgur.com/dwgoHY8.png)